console.log("Hello World");

function fun1()
{
    var obj = {
        authorName: 'Ryan Dahl',
        language: 'Node.js'
    }
    console.log(obj)
}

fun1()

