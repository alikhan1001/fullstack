exports.printMsg = function() {
  console.log("This is a message from the demo package");
};

exports.myDateTime = function () {
    return Date();
};