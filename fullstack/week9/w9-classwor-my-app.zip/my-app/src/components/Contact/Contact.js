import React, {Fragment} from 'react'

function Contact(props) {
  return (
      //read props wiht given name
      <h2>{`${props.firstName} ${props.lastName}`}</h2>
  );
}

//Set Default Props values
Contact.defaultProps = {
    firstName: "No First Name",
    lastName:"No Last Name"
 }
 
export default Contact;
