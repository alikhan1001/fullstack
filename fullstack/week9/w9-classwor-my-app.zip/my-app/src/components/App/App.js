import './App.css';
import React, {Fragment} from 'react'
import Header from "../Header/Header"
import Contact from "../Contact/Contact"

function App() {

  return (
    <React.Fragment>
      <Header color="green"/>
      <Header color="blue"/>
      <Contact firstName="Pritesh" lastName="Patel"/>
      <Contact firstName="Sahil" lastName="."/>
      <Contact firstName="Suvash" lastName="Sharma"/>
      <Contact firstName="Gordon" lastName="Wells"/>
      <Contact />
    </React.Fragment>
  );
}

export default App;
