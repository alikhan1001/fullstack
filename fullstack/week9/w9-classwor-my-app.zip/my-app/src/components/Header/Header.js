import React, {Fragment} from 'react'

class Header extends React.Component {
    
    //Set props as a constructor values
    constructor(props)
    {
        super(props)
    }

    //Declare State Object default values
    state = {
        title : "Welcome to ReachJS Programming..."
    }

    render()
    {
        return (
        //Use props and state values
        <h1 style ={{color: this.props.color}}>{this.state.title}</h1>
        );
    }
}

export default Header;
